 console.log("lala");

function Validate (form){
    if (!confirmname(form.FullName.value)){
        return false;
    }
    if(!confirmphone(form.Phone.value))
    {
        return false;
    }
    if(!confirmaddress(form.alamat.value))
    {
        return false;
    }
    if(!confirmproduct(form.Product.value))
    {
        return false;
    }
    if(!confirmquantity(form.quantity.value))
    {
        return false;
    }

    return true;
}

function confirmname (data){
if(data == "")
{
alert ("Name Cannot be blank!");
return false;
}
return true;
}


function confirmphone (data){
if(data == "")
{
alert ("Phone Number Cannot be blank!");
return false;
}
return true;
}

function confirmaddress (data){
    if(data == "")
    {
    alert ("Address Cannot be blank!");
    return false;
    }
    return true;
    }
    

    function confirmproduct (data){
        if(data == "")
        {
        alert ("product Cannot be blank!");
        return false;
        }
        return true;
        }

        function confirmquantity (data){
            if(data == "")
            {
            alert ("quantity Cannot be blank!");
            return false;
            }
            return true;
            }
        